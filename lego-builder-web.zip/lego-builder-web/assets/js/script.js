// script.js
// Add the same JavaScript content you've been working on here.
console.log("Lego Lab initialized!");
